package com.example.mahua_pet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
