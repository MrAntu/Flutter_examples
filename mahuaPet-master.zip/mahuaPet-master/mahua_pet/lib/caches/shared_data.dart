import 'package:mahua_pet/providered/model/model_index.dart';

class SharedData {
  
  /// 登录信息
  /// 当前用户userID
  static int userId = 0;

  
}