import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';


class CollegeTest extends StatefulWidget {
  @override
  _CollegeTestState createState() => _CollegeTestState();
}

class _CollegeTestState extends State<CollegeTest> {

  @override
  void initState() {
    super.initState();

    // EasyLoading.showSuccess('status');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(

      ),
    );
  }
}