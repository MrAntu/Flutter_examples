
class TopicURL {
  
  /// 热门话题: user/tribe/v2004/lik/getHotTribe?dogBreedId=102
  static const String getHotTribe = 'user/tribe/v2004/lik/getHotTribe';

  /// 热门讨论: user/question/v1911/lt/selectQuestionHotList?pageIndex=1&pageSize=6&userId=136899
  static const String selectQuestionHotList = 'user/question/v1911/lt/selectQuestionHotList';

  /// 讨论点赞-user/agree/updateAgree?agreeStatus=1&answerId=945&userId=136899
  static const String updateAgree = 'user/agree/updateAgree';






}