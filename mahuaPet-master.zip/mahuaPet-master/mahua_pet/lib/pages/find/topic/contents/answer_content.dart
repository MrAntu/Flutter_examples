import 'package:flutter/material.dart';
import 'package:mahua_pet/styles/app_style.dart';

class AnswerContent extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      // child: ,
    );
  }
}