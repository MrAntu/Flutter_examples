List listData = [
  {
    "title": "title1",
    "phone": "111xxxx",
    "content": "content1-content1-content1-content1-ccontent1-content1",
    "imageUrl": "https://gitee.com/iotjh/Picture/raw/master/lufei.png"
  },
  {
    "title": "title2",
    "phone": "222xxxx",
    "content": "content2-content2-content2-content2-content2-content2",
    "imageUrl": "https://gitee.com/iotjh/Picture/raw/master/lufei.png"
  },
  {
    "title": "title3",
    "phone": "333xxxx",
    "content": "content3-content3-content3-content3-content3-content3",
    "imageUrl": "https://gitee.com/iotjh/Picture/raw/master/lufei.png"
  },
  {
    "title": "title4",
    "phone": "444xxxx",
    "content": "content4-content4-content4-content4-content4-content4",
    "imageUrl": "https://gitee.com/iotjh/Picture/raw/master/lufei.png"
  },
  {
    "title": "title5",
    "phone": "555xxxx",
    "content": "content5-content5-content5-content5-content5-content5",
    "imageUrl": "https://gitee.com/iotjh/Picture/raw/master/lufei.png"
  },
  {
    "title": "title6",
    "phone": "666xxxx",
    "content": "content6-content6-content6-content6-content6-content6",
    "imageUrl": "https://gitee.com/iotjh/Picture/raw/master/lufei.png"
  },
  {
    "title": "title7",
    "phone": "777xxxx",
    "content": "content7-content7-content7-content7-content7-content7",
    "imageUrl": "https://gitee.com/iotjh/Picture/raw/master/lufei.png"
  }
];

List listData222 = [
  {
    "title": "title11",
    "icon": "service/icon_baoxiu",
    "bgImg": "service/bg_service_baoxiu"
  }
];

List groupData = [
  {
    "groupTitle": "groupTitle_1",
    "num": "22",
    "data": [
      {
        "title": "group1_title11",
        "phone": "111xxxx",
        "content": "content2-content2-content2-content2-content2-content2",
        "imageUrl": "https://gitee.com/iotjh/Picture/raw/master/lufei.png"
      },
      {
        "title": "group1_title2",
        "phone": "222xxxx",
        "content": "content2-content2-content2-content2-content2-content2",
        "imageUrl": "https://gitee.com/iotjh/Picture/raw/master/lufei.png"
      }
    ]
  },
  {
    "groupTitle": "groupTitle_2",
    "num": "22",
    "data": [
      {
        "title": "group2_title33",
        "phone": "333xxxx",
        "content": "content2-content2-content2-content2-content2-content2",
        "imageUrl": "https://gitee.com/iotjh/Picture/raw/master/lufei.png"
      },
      {
        "title": "group2_title44",
        "phone": "444xxxx",
        "content": "content2-content2-content2-content2-content2-content2",
        "imageUrl": "https://gitee.com/iotjh/Picture/raw/master/lufei.png"
      }
    ]
  }
];
