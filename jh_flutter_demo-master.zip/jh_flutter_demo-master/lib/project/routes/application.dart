import 'package:fluro/fluro.dart';

class Application {
  static FluroRouter router;
}
