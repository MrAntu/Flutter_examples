/**
 *  apis.dart
 *
 *  Created by iotjin on 2020/07/06.
 *  description:  api 配置
 */

const base_url = "http://10.20.20.97:3000/";
const test = "测试上传";